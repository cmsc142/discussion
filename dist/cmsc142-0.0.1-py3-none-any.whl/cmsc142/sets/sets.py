# list without order
# can't have duplicates
# downside: checking for duplicates can take a really long time
# 
# hash function
# takes a range of values (strings, objects, so on) -> index
# set = []
# len(thing) % 6 = 4
# "Ethan" "Etham"
# [.... ["Ethan", "Etham"]  ....]